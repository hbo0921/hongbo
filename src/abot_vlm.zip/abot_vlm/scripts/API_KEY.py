#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 零一万物大模型开放平台
# https://platform.lingyiwanwu.com
YI_KEY = "0a4cb2d4916f494c9ffc7327048a2635"
